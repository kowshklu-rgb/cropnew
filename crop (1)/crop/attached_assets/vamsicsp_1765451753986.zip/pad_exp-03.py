
from scipy.stats import ttest_1samp
import numpy as np

def one_sample_t_test(data, population_mean):
    t_stat, p_value = ttest_1samp(data, population_mean)
    return t_stat, p_value

data = [12, 13, 11, 14, 15, 10, 13, 12, 13, 14]
population_mean = 12

t_stat, p_value = one_sample_t_test(data, population_mean)
print(f"T-Statistic: {t_stat}")
print(f"P-Value: {p_value}")

from scipy.stats import ttest_ind

def independent_t_test(sample1, sample2, equal_var=True):
    t_stat, p_value = ttest_ind(sample1, sample2, equal_var=equal_var)
    return t_stat, p_value

sample1 = [20, 21, 19, 22, 20, 21, 19]
sample2 = [18, 17, 16, 19, 18, 17, 16]

t_stat, p_value = independent_t_test(sample1, sample2)
print(f"T-Statistic: {t_stat}")
print(f"P-Value: {p_value}")


from scipy.stats import ttest_rel

def paired_t_test(sample1, sample2):
    t_stat, p_value = ttest_rel(sample1, sample2)
    return t_stat, p_value

before = [20, 22, 19, 21, 20]
after = [21, 23, 20, 22, 21]

t_stat, p_value = paired_t_test(before, after)
print(f"T-Statistic: {t_stat}")
print(f"P-Value: {p_value}")