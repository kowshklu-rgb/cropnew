# Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib

# Load the dataset

data = pd.read_csv(r'C:\Users\kowsh\OneDrive\csp project\crop_recommendation_with_districts.csv')

# Separate features and target variable
X = data.drop(columns=['price'])
y = data['price']

# Preprocess categorical variables
crop_dict = {
    'rice': 1, 'maize': 2, 'jute': 3, 'cotton': 4, 'coconut': 5,
    'papaya': 6, 'orange': 7, 'apple': 8, 'muskmelon': 9, 'watermelon': 10,
    'grapes': 11, 'mango': 12, 'banana': 13, 'pomegranate': 14, 
    'lentil': 15, 'blackgram': 16, 'mungbean': 17, 'mothbeans': 18, 
    'pigeonpeas': 19, 'kidneybeans': 20, 'chickpea': 21, 'coffee': 22,
    'groundnut': 23, 'wheat': 24, 'onion': 25, 'barley': 26, 'clover': 27,
    'oats': 28
}
season_dict = {
    'Kharif': 1, 'Rabi': 2
}


categorical_features = ['temperature','humidity','rainfall','season','label','district','price']

# Define preprocessing for categorical data
preprocessor = ColumnTransformer(
    transformers=[
        ('cat', OneHotEncoder(drop='first'), categorical_features)
    ],
    remainder='passthrough'  # Keep other columns as is
)

# Create the pipeline with preprocessing and the model
model_pipeline = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('model', LinearRegression())
])

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Fit the model
model_pipeline.fit(X_train, y_train)
print("Model training complete.")

# Make predictions and evaluate the model
y_pred = model_pipeline.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f'Mean Absolute Error: {mae}')
print(f'R-squared: {r2}')

# Save the trained model
save_model = input("Do you want to save the trained model? (yes/no): ").strip().lower()
if save_model == 'yes':
    model_path = input("Enter the file path to save the model (e.g., crop_price_prediction_model.pkl): ")
    joblib.dump(model_pipeline, model_path)
    print(f"Model saved to {model_path}.")

# Direct prediction based on user input
predict_direct = input("Would you like to predict a price for a new set of conditions? (yes/no): ").strip().lower()
if predict_direct == 'yes':
    # Take individual parameter inputs from the user
    print("Please provide the following parameters for prediction:")
    temperature = float(input("Temperature: "))
    humidity = float(input("Humidity: "))
    rainfall = float(input("Rainfall: "))
    season = input("Season (e.g., kharif): ")
    label = input("Crop label (e.g., rice): ")
    district = input("District: ")

    # Create a DataFrame for the input parameters
    input_data = pd.DataFrame([{
        'temperature': temperature, 'humidity': humidity, 'rainfall': rainfall,
        'season': season,  'label': label, 
        'district': district
    }])

    # Predict the price
    predicted_price = model_pipeline.predict(input_data)
    print(f"Predicted crop price: {predicted_price[0]:.2f}")
else:
    print("Prediction process skipped.")
