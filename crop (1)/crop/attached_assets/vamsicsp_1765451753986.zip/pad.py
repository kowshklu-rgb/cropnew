import requests
import google.generativeai as genai
import pandas as pd
import numpy as np

# Configure Gemini API
genai.configure(api_key="your_gemini_api_key")

# API KEYS (Replace with your actual API keys)
WEATHER_API_KEY = "529a2eba049222c4c04838867e6bd9b8"
SOIL_API_KEY = "your_soil_api_key"

# Function to fetch weather and soil data
def fetch_data(lat, lon):
    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?id=524901&appid={WEATHER_API_KEY}"
    soil_url = f"https://rest.soilgrids.org/query?lon={lon}&lat={lat}&depth=0-5cm"
    
    weather_response = requests.get(weather_url).json()
    soil_response = requests.get(soil_url).json()
    
    # Extract relevant features
    temperature = weather_response['main']['temp']
    humidity = weather_response['main']['humidity']
    soil_type = soil_response['properties']['TAXNWRB']['classification']
    npk = soil_response['properties']['NPK']['value']  # Example, check API response
    ph = soil_response['properties']['phh2o']['value']  # Example
    
    return [temperature, humidity, npk, ph, soil_type]

# Function to use Gemini API for prediction
def predict_soil_fertility(temp, humidity, npk, ph, soil_type):
    prompt = f"Predict soil fertility based on these values: Temperature={temp}, Humidity={humidity}, NPK={npk}, pH={ph}, Soil Type={soil_type}. Return 'Fertile' or 'Infertile'."
    response = genai.GenerativeModel("gemini-pro").generate_content(prompt)
    return response.text.strip()

# Example Usage
lat, lon = 37.7749, -122.4194  # Example coordinates
weather_soil_data = fetch_data(lat, lon)
print(predict_soil_fertility(*weather_soil_data))
